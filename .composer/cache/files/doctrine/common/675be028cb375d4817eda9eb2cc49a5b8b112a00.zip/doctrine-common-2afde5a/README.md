# Doctrine Common

[![Build Status](https://github.com/doctrine/common/workflows/Continuous%20Integration/badge.svg)](https://github.com/doctrine/common/actions)

The Doctrine Common project is a library that provides extensions to core PHP functionality.

## More resources:

* [Website](https://www.doctrine-project.org/)
* [Documentation](https://www.doctrine-project.org/projects/doctrine-common/en/latest/)
* [Downloads](https://github.com/doctrine/common/releases)
